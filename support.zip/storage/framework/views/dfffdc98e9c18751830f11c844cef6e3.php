<div>TEST VIEW OK</div>
<?php /**PATH /var/www/html/resources/views/test-view.blade.php ENDPATH**/ ?>