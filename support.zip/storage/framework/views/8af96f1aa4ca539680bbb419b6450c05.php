<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Tickets'); ?></title>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>