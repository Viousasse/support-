<?php return array (
  'laravel/boost' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Boost\\BoostServiceProvider',
    ),
  ),
  'laravel/mcp' => 
  array (
    'aliases' => 
    array (
      'Mcp' => 'Laravel\\Mcp\\Facades\\Mcp',
    ),
    'providers' => 
    array (
      0 => 'Laravel\\Mcp\\Server\\McpServiceProvider',
    ),
  ),
  'laravel/pail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Pail\\PailServiceProvider',
    ),
  ),
  'laravel/pao' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Pao\\Laravel\\ServiceProvider',
    ),
  ),
  'laravel/roster' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Roster\\RosterServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
  ),
  'lomkit/laravel-access-control' => 
  array (
    'aliases' => 
    array (
      'Access' => 'Lomkit\\Access\\Facades\\Access',
    ),
    'providers' => 
    array (
      0 => 'Lomkit\\Access\\AccessServiceProvider',
    ),
  ),
  'lomkit/laravel-rest-api' => 
  array (
    'aliases' => 
    array (
      'Rest' => 'Lomkit\\Rest\\Facades\\Rest',
    ),
    'providers' => 
    array (
      0 => 'Lomkit\\Rest\\RestServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'orchestra/canvas' => 
  array (
    'providers' => 
    array (
      0 => 'Orchestra\\Canvas\\LaravelServiceProvider',
    ),
  ),
  'orchestra/canvas-core' => 
  array (
    'providers' => 
    array (
      0 => 'Orchestra\\Canvas\\Core\\LaravelServiceProvider',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'support/tickets' => 
  array (
    'providers' => 
    array (
      0 => 'Layers\\Tickets\\Providers\\TicketsServiceProvider',
    ),
  ),
  'xefi/faker-php-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Xefi\\Faker\\Laravel\\FakerLaravelServiceProvider',
    ),
  ),
  'xefi/laravel-osdd' => 
  array (
    'providers' => 
    array (
      0 => 'Xefi\\LaravelOSDD\\LaravelOSDDServiceProvider',
    ),
  ),
);